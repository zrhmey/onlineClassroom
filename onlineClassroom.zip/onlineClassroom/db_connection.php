<?php
 		$host = 'localhost';
		$username = 'root';
		$password = '';
		$db = 'onlineclassroom';
		$dbconn = mysqli_connect($host,$username,$password,$db) or die("Could not connect to database!");
?>